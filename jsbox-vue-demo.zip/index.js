const webpack = require("webpack");
const WebpackDevServer = require("webpack-dev-server");
const config = require("./build/webpack.prod.conf");
const port = 8080;

const options = {
  publicPath: config.output.publicPath,
  hot: true,
  inline: true,
  contentBase: "www",
  stats: {
    colors: false
  }
};

console.log("Starting the dev web server...");
const server = new WebpackDevServer(webpack(config), options);
server.listen(port, "localhost", err => {
  if (err) {
    console.log(err);
  }
  console.log("WebpackDevServer listening at localhost:", port);
});